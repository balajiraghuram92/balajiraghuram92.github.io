import requests
from bs4 import BeautifulSoup

HEADERS =   {
                "User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                                "AppleWebKit/537.36 (KHTML, like Gecko) "
                                 "Chrome/120.0 Safari/537.36",
                "Accept" : "text/html, application/xhtml+xml, application/xml;q=0.9,*/*,q=0.8",
                "Accept-Language": "en-US,en,q=0.9",             
            }

def fetch_website_contents(url):
    if not url.startswith(("https://", "http://")):
        url = "https://" + url 

    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        return f"Could not fecth the website. {e}"
    
    soup = BeautifulSoup(response.text, "html.parser")
    title = soup.title.string if soup.title else "No Title found"


    for tag in soup(["script", "style", "nav", "footer", "header", "img", "input" ]):
        tag.decompose()

    text = soup.get_text(separator="\n", strip=True)

    return f"Title: {title},'\n' Page Contents: {text}"

if __name__ == "__main__":
    print(fetch_website_contents("anthropic.com")[:500])